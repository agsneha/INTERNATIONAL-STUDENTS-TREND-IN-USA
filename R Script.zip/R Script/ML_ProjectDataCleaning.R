library(dplyr)
library(tidyr)

# Load the data
CombinedData <- read.csv("/Users/snehaagrawal/Documents/SEM 2/ML/Term Project/Dataset/ML_Dataset.csv")

# Checking for missing values
missing_values <- colSums(is.na(CombinedData))
print(missing_values)

# Focusing on data from 2012
CombinedData <- subset(CombinedData, Year >= 2012)
print(head(CombinedData))

# Rechecking missing values
missing_values <- colSums(is.na(CombinedData))
print(missing_values)

# Box plots for numeric variables
numeric_vars <- sapply(CombinedData, is.numeric)
boxplot(CombinedData[, numeric_vars], main = "Box Plots of Numeric Variables in CombinedData", las = 2)

# Standarization
# Excluding columns 1, 2, and 4
columns_to_standardize <- names(CombinedData)[-c(1, 2, 4)]

str(CombinedData[, columns_to_standardize])

# Remove commas
comma_columns <- c("Personal.and.Family", "Foreign.Government.or.University",
                   "Foreign.Private.Sponsor", "International.Organization",
                   "U.S..Funding.Sources", "Current.Employment",
                   "U.S..College.or.University.", "U.S..Government",
                   "Other.Sources")

CombinedData[, comma_columns] <- lapply(CombinedData[, comma_columns], function(x) as.numeric(gsub(",", "", x)))

# Convert the selected columns to numeric
CombinedData[, columns_to_standardize] <- lapply(CombinedData[, columns_to_standardize], as.numeric)

CombinedData[, columns_to_standardize] <- scale(CombinedData[, columns_to_standardize])

head(CombinedData)

summary(CombinedData[, columns_to_standardize])
colSums(is.na(CombinedData[, columns_to_standardize]))


# One-hot encoding on categorical data
CombinedData$Degree <- factor(CombinedData$Degree)
CombinedData$Field.of.Study <- factor(CombinedData$Field.of.Study)

one_hot_encoding_degree <- model.matrix(~ Degree - 1, data = CombinedData)
one_hot_encoding_field <- model.matrix(~ Field.of.Study - 1, data = CombinedData)

one_hot_df_degree <- as.data.frame(one_hot_encoding_degree)
one_hot_df_field <- as.data.frame(one_hot_encoding_field)

degree_index <- which(names(CombinedData) == "Degree")
field_index <- which(names(CombinedData) == "Field.of.Study")

CombinedData <- cbind(CombinedData[, 1:degree_index], one_hot_df_degree, CombinedData[, (degree_index+1):field_index], one_hot_df_field, CombinedData[, (field_index+1):ncol(CombinedData)])

# Removing 'Degree' and 'Field.of.Study' from the final data frame
CombinedData <- subset(CombinedData, select = -c(Degree, Field.of.Study))

# Clean column names
names(CombinedData) <- gsub("[.]", "", names(CombinedData))

CombinedData <- CombinedData %>%
  rename(TotalofDegree = Degreetotal,
         TotalStudyField = Fieldofstudytotal)

str(CombinedData)
names(CombinedData)

# Saving data
write.csv(CombinedData, "/Users/snehaagrawal/Documents/SEM 2/ML/Term Project/Dataset/Cleaned_CombinedData.csv", row.names = FALSE)




# Loading data (2): International student distribution in US by country data
CountryDistribution <- read.csv("/Users/snehaagrawal/Documents/SEM 2/ML/Term Project/Dataset/Census_All-Places-of-Origin_OD23.csv")
print(names(CountryDistribution))

# Remove the starting "X" from column names
CountryDistribution <- CountryDistribution %>%
  rename_with(~sub("^X", "", .))

# Now, remove columns from 2002 to 2011
CountryDistribution <- CountryDistribution %>%
  dplyr::select(-matches("^(X200[2-9]|X201[01])"))

# Convert all columns except Place_of_Origin to numeric and remove commas and other signs
CountryDistribution <- CountryDistribution %>%
  mutate(across(-Place_of_Origin, ~as.numeric(gsub("[^0-9]", "", gsub(",", "", .)))))

# Check the structure of the data after conversion
str(CountryDistribution)

# Check for missing values in country dataset
missing_values <- colSums(is.na(CountryDistribution))
print(missing_values)

# Replace missing values with row means for numeric columns only
CountryDistribution <- CountryDistribution %>%
  mutate(across(where(is.numeric), ~ifelse(is.na(.), mean(., na.rm = TRUE), .)))

# Recheck missing values
missing_values <- colSums(is.na(CountryDistribution))
print(missing_values)

# Remove rows where all values are zero (excluding the first column Place_of_Origin)
CountryDistribution <- CountryDistribution[rowSums(CountryDistribution[, -1] == 0) != (ncol(CountryDistribution) - 1), ]

# Generate box plots for numeric variables
numeric_vars <- sapply(CountryDistribution, is.numeric)
boxplot(CountryDistribution[, numeric_vars], main = "Box Plots of Numeric Variables in CountryDistribution", las = 2)

# Save the cleaned CountryDistribution to a CSV file
write.csv(CountryDistribution, "/Users/snehaagrawal/Documents/SEM 2/ML/Term Project/Dataset/Cleaned_CountryDistribution.csv", row.names = FALSE)
