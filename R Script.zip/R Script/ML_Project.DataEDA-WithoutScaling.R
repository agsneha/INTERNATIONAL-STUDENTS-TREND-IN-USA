library(dplyr)
library(tidyr)

CombinedData <- read.csv("/Users/snehaagrawal/Documents/SEM 2/ML/Term Project/Dataset/ML_Dataset.csv")
CombinedData <- subset(CombinedData, Year >= 2012)

# Remove commas from numeric columns
comma_columns <- c("Personal.and.Family", "Foreign.Government.or.University",
                   "Foreign.Private.Sponsor", "International.Organization",
                   "U.S..Funding.Sources", "Current.Employment",
                   "U.S..College.or.University.", "U.S..Government",
                   "Other.Sources")
CombinedData[, comma_columns] <- lapply(CombinedData[, comma_columns], function(x) as.numeric(gsub(",", "", x)))

# One-hot encoding on categorical data
CombinedData$Degree <- factor(CombinedData$Degree)
CombinedData$Field.of.Study <- factor(CombinedData$Field.of.Study)
one_hot_encoding_degree <- model.matrix(~ Degree - 1, data = CombinedData)
one_hot_encoding_field <- model.matrix(~ Field.of.Study - 1, data = CombinedData)
one_hot_df_degree <- as.data.frame(one_hot_encoding_degree)
one_hot_df_field <- as.data.frame(one_hot_encoding_field)
degree_index <- which(names(CombinedData) == "Degree")
field_index <- which(names(CombinedData) == "Field.of.Study")
CombinedData <- cbind(CombinedData[, 1:degree_index], one_hot_df_degree, CombinedData[, (degree_index+1):field_index], one_hot_df_field, CombinedData[, (field_index+1):ncol(CombinedData)])

# Removing 'Degree' and 'Field.of.Study' 
CombinedData <- subset(CombinedData, select = -c(Degree, Field.of.Study))

# Cleaning column names
names(CombinedData) <- gsub("[.]", "", names(CombinedData))

# Converting all columns (except "Year") to numeric
CombinedData[, -1] <- lapply(CombinedData[, -1], as.numeric)

CombinedData <- CombinedData %>%
  rename(TotalofDegree = Degreetotal, TotalofStudyField = Fieldofstudytotal)

str(CombinedData)

# Output directory to save plots
output_dir <- "/Users/snehaagrawal/Documents/SEM 2/ML/Term Project/EDA/CombinedData_Plot"


#### Trend analysis
trend_plot <- ggplot(CombinedData, aes(x = Year, y = TotalIntlStudents)) +
  geom_line(color = brewer.pal(9, "Set1")[1]) +
  geom_point(color = brewer.pal(9, "Set1")[2]) +
  labs(x = "Year", y = "Total International Students", title = "Trend of International Students over the Years") +
  theme_minimal()
ggsave(file.path(output_dir, "StudentTrendinUSA_plot.png"), plot = trend_plot, width = 10, height = 6, dpi = 300)

max_students <- max(CombinedData$TotalIntlStudents)
max_students_year <- CombinedData$Year[which.max(CombinedData$TotalIntlStudents)]
min_students <- min(CombinedData$TotalIntlStudents)
min_students_year <- CombinedData$Year[which.min(CombinedData$TotalIntlStudents)]

cat("Maximum international students:", max_students, "in", max_students_year, "\n")
cat("Minimum international students:", min_students, "in", min_students_year, "\n")


#### Percentage Change Analysis
change_plot <- ggplot(CombinedData, aes(x = Year, y = AnnualChange)) +
  geom_line(color = brewer.pal(9, "Blues")[5]) +
  geom_point(color = brewer.pal(9, "Reds")[5]) +
  labs(title = "Year-over-Year Percentage Change in International Student Enrollment",
       x = "Year", y = "Percentage Change") +
  theme_minimal()
ggsave(file.path(output_dir, "PercentageChangein_IntStudents.png"), plot = change_plot, width = 10, height = 6, dpi = 300)

max_increase <- max(CombinedData$AnnualChange)
max_increase_year <- CombinedData$Year[which.max(CombinedData$AnnualChange)]
max_decrease <- min(CombinedData$AnnualChange)
max_decrease_year <- CombinedData$Year[which.min(CombinedData$AnnualChange)]

cat("Maximum increase in international students:", max_increase, "% in", max_increase_year, "\n")
cat("Maximum decrease in international students:", max_decrease, "% in", max_decrease_year, "\n")


#### Degree Level Analysis - Pie Chart
degree_columns <- names(CombinedData)[grepl("^Degree", names(CombinedData))]
degree_data <- CombinedData[, degree_columns]
degree_totals <- colSums(degree_data)
degree_df <- data.frame(Degree = names(degree_totals), Total = degree_totals)

degree_plot <- ggplot(degree_df, aes(x = "", y = Total, fill = Degree)) +
  geom_bar(stat = "identity", width = 1) +
  coord_polar(theta = "y") +
  labs(title = "Pie Chart of International Students by Degree Level") +
  theme_void() +
  scale_fill_brewer(palette = "Dark2")
ggsave(file.path(output_dir, "Degree_pie_chart.png"), plot = degree_plot, width = 10, height = 6, dpi = 300)

max_degree <- max(degree_totals)
max_degree_name <- names(degree_totals)[which.max(degree_totals)]
min_degree <- min(degree_totals)
min_degree_name <- names(degree_totals)[which.min(degree_totals)]

cat("Maximum international students by degree:", max_degree, "in", max_degree_name, "\n")
cat("Minimum international students by degree:", min_degree, "in", min_degree_name, "\n")


#### Field of Study Analysis - Donut Chart
field_columns <- names(CombinedData)[grepl("^FieldofStudy", names(CombinedData))]
field_data <- CombinedData[, field_columns]
field_totals <- colSums(field_data)
field_df <- data.frame(Field = names(field_totals), Total = field_totals)

field_plot <- ggplot(field_df, aes(x = "", y = Total, fill = Field)) +
  geom_bar(stat = "identity", width = 1) +
  coord_polar(theta = "y", start = 0) +
  labs(title = "Donut Chart of International Students by Field of Study") +
  theme_void() +
  scale_fill_brewer(palette = "Paired")
ggsave(file.path(output_dir, "Field_study_donut_chart.png"), plot = field_plot, width = 10, height = 6, dpi = 300)

max_field <- max(field_totals)
max_field_name <- names(field_totals)[which.max(field_totals)]
min_field <- min(field_totals)
min_field_name <- names(field_totals)[which.min(field_totals)]

cat("Maximum international students by field of study:", max_field, "in", max_field_name, "\n")
cat("Minimum international students by field of study:", min_field, "in", min_field_name, "\n")


#### Demographic Analysis - Gender Distribution by Year
demographic_data <- CombinedData[, c("Year", "female", "male")]

demographic_plot <- ggplot(demographic_data, aes(x = Year)) +
  geom_col(aes(y = female, fill = "Female"), width = 0.4, position = position_nudge(x = -0.2)) +
  geom_col(aes(y = male, fill = "Male"), width = 0.4, position = position_nudge(x = 0.2)) +
  scale_fill_manual(values = c("Female" = "#F8766D", "Male" = "#00BFC4")) +
  labs(x = "Year", y = "Enrollment", title = "Gender Distribution of International Students Over Years") +
  theme_minimal() +
  theme(legend.position = "bottom") +
  geom_text(aes(y = female, label = scales::comma(female)), position = position_nudge(x = -0.2), vjust = -0.5, color = "black", size = 3) +
  geom_text(aes(y = male, label = scales::comma(male)), position = position_nudge(x = 0.2), vjust = -0.5, color = "black", size = 3) +
  scale_y_continuous(labels = scales::comma)
ggsave(file.path(output_dir, "demographic_plot.png"), plot = demographic_plot, width = 10, height = 6, dpi = 300)

max_female <- max(CombinedData$female)
max_female_year <- CombinedData$Year[which.max(CombinedData$female)]
min_female <- min(CombinedData$female)
min_female_year <- CombinedData$Year[which.min(CombinedData$female)]

max_male <- max(CombinedData$male)
max_male_year <- CombinedData$Year[which.max(CombinedData$male)]
min_male <- min(CombinedData$male)
min_male_year <- CombinedData$Year[which.min(CombinedData$male)]

cat("Maximum female international students:", max_female, "in", max_female_year, "\n")
cat("Minimum female international students:", min_female, "in", min_female_year, "\n")
cat("Maximum male international students:", max_male, "in", max_male_year, "\n")
cat("Minimum male international students:", min_male, "in", min_male_year, "\n")


#### Funding Source Analysis - Horizontal Bar Chart
funding_columns <- names(CombinedData)[grepl("Funding", names(CombinedData))]
funding_data <- CombinedData[, funding_columns]
funding_totals <- colSums(funding_data)
funding_df <- data.frame(FundingSource = names(funding_totals), Total = funding_totals)

funding_plot <- ggplot(funding_df, aes(x = reorder(FundingSource, Total), y = Total, fill = FundingSource)) +
  geom_bar(stat = "identity") +
  coord_flip() +
  scale_fill_brewer(palette = "Set3") +
  labs(x = "Funding Source", y = "Number of Students", title = "Distribution of International Students by Funding Source") +
  theme_minimal()
ggsave(file.path(output_dir, "funding_plot.png"), plot = funding_plot, width = 10, height = 6, dpi = 300)

max_funding <- max(funding_totals)
max_funding_source <- names(funding_totals)[which.max(funding_totals)]
min_funding <- min(funding_totals)
min_funding_source <- names(funding_totals)[which.min(funding_totals)]

cat("Maximum international students by funding source:", max_funding, "in", max_funding_source, "\n")
cat("Minimum international students by funding source:", min_funding, "in", min_funding_source, "\n")


#### Top Universities Analysis - Horizontal Bar Chart
university_columns <- names(CombinedData)[grepl("University", names(CombinedData))]
university_data <- CombinedData[, university_columns]
university_totals <- colSums(university_data)
university_df <- data.frame(University = names(university_totals), TotalEnrollment = university_totals)

# Sort in descending order
university_df <- university_df[order(-university_df$TotalEnrollment), ]

# Top 20 universities
top_universities <- head(university_df, 20)

university_plot <- ggplot(top_universities, aes(x = reorder(University, TotalEnrollment), y = TotalEnrollment, fill = University)) +
  geom_bar(stat = "identity") +
  coord_flip() +
  scale_fill_viridis_d(option = "viridis") +  # Use viridis color palette
  labs(x = "University", y = "Total Enrollment", title = "Top 20 Universities by Enrollment of International Students") +
  theme_minimal()
ggsave(file.path(output_dir, "top_universities_plot.png"), plot = university_plot, width = 10, height = 6, dpi = 300)

top_university <- university_df$University[1]
top_university_enrollment <- university_df$TotalEnrollment[1]
least_university <- university_df$University[nrow(university_df)]
least_university_enrollment <- university_df$TotalEnrollment[nrow(university_df)]

cat("Top university for international students:", top_university, "with", top_university_enrollment, "students\n")
cat("University with least international students:", least_university, "with", least_university_enrollment, "students\n")


#### Visa Status Analysis - Vertical Bar Chart
visa_columns <- names(CombinedData)[grepl("^visa", names(CombinedData))]
visa_data <- CombinedData[, visa_columns]
visa_totals <- colSums(visa_data)
visa_df <- data.frame(VisaType = names(visa_totals), Total = visa_totals)

visa_plot <- ggplot(visa_df, aes(x = VisaType, y = Total, fill = VisaType)) +
  geom_bar(stat = "identity") +
  scale_fill_brewer(palette = "Set2") +
  labs(x = "Visa Type", y = "Number of Students", title = "Distribution of International Students by Visa Status") +
  theme_minimal()
ggsave(file.path(output_dir, "visa_plot.png"), plot = visa_plot, width = 10, height = 6, dpi = 300)

max_visa <- max(visa_totals)
max_visa_type <- names(visa_totals)[which.max(visa_totals)]
min_visa <- min(visa_totals)
min_visa_type <- names(visa_totals)[which.min(visa_totals)]

cat("Maximum international students by visa type:", max_visa, "in", max_visa_type, "\n")
cat("Minimum international students by visa type:", min_visa, "in", min_visa_type, "\n")


#### Optional Practical Training (OPT) Analysis - Area Chart
opt_data <- CombinedData[, c("Year", "OptionalPracticalTrainingOPT")]

opt_plot <- ggplot(opt_data, aes(x = Year, y = OptionalPracticalTrainingOPT, fill = "OPT Participation")) +
  geom_area(alpha = 0.5, fill = brewer.pal(9, "Greens")[5]) +
  geom_line(color = brewer.pal(9, "Greens")[9]) +
  labs(x = "Year", y = "OPT Participation", title = "Trend of Optional Practical Training (OPT) Participation") +
  theme_minimal()
ggsave(file.path(output_dir, "opt_plot.png"), plot = opt_plot, width = 10, height = 6, dpi = 300)

max_opt <- max(CombinedData$OptionalPracticalTrainingOPT)
max_opt_year <- CombinedData$Year[which.max(CombinedData$OptionalPracticalTrainingOPT)]
min_opt <- min(CombinedData$OptionalPracticalTrainingOPT)
min_opt_year <- CombinedData$Year[which.min(CombinedData$OptionalPracticalTrainingOPT)]

cat("Maximum international students in OPT:", max_opt, "in", max_opt_year, "\n")
cat("Minimum international students in OPT:", min_opt, "in", min_opt_year, "\n")


