library(tidyr)
library(ggplot2)
library(dplyr)
library(scales)
library(RColorBrewer)

# Directory to save the plots
output_dir <- "/Users/snehaagrawal/Documents/SEM 2/ML/Term Project/EDA/CombinedPlot- ScaledData"

# Loading the cleaned data set
data <- read.csv("/Users/snehaagrawal/Documents/SEM 2/ML/Term Project/Dataset/Cleaned_CombinedData.csv")
print(names(data))



#### Trend Analysis
trend_plot <- ggplot(data, aes(x = Year, y = TotalIntlStudents)) +
  geom_line(color = brewer.pal(9, "Set1")[1]) +
  geom_point(color = brewer.pal(9, "Set1")[2]) +
  labs(x = "Year", y = "Total International Students", title = "Trend of International Students over the Years")
ggsave(file.path(output_dir, "StudentTrendinUSA_plot.png"), plot = trend_plot, width = 10, height = 6, dpi = 300)
highest_year <- data[which.max(data$TotalIntlStudents), ]
lowest_year <- data[which.min(data$TotalIntlStudents), ]
print(paste("Year with the highest total international students:", highest_year$Year))
print(paste("Year with the lowest total international students:", lowest_year$Year))

# Percentage Change Analysis
change_plot <- ggplot(data, aes(x = Year, y = AnnualChange)) +
  geom_line(color = brewer.pal(9, "Blues")[5]) +
  geom_point(color = brewer.pal(9, "Reds")[5]) +
  labs(title = "Year-over-Year Percentage Change in International Student Enrollment",
       x = "Year", y = "Percentage Change") +
  theme_minimal()
ggsave(file.path(output_dir, "PercentageChangein_IntStudents.png"), plot = change_plot, width = 10, height = 6, dpi = 300)
highest_change <- data[which.max(data$AnnualChange), ]
lowest_change <- data[which.min(data$AnnualChange), ]
print(paste("Year with the highest percentage change:", highest_change$Year))
print(paste("Year with the lowest percentage change:", lowest_change$Year))


#### Degree Level Analysis - Pie Chart
degree_counts <- data %>%
  dplyr::select(dplyr::starts_with("Degree")) %>%
  summarize_all(sum)
degree_counts_long <- pivot_longer(degree_counts, cols = everything(), names_to = "Degree", values_to = "Total")
degree_plot <- ggplot(degree_counts_long, aes(x = "", y = Total, fill = Degree)) +
  geom_bar(stat = "identity", width = 1) +
  coord_polar(theta = "y") +
  labs(title = "Pie Chart of International Students by Degree Level") +
  theme_void() +
  geom_text(aes(label = scales::comma(Total)), position = position_stack(vjust = 0.5)) +
  scale_fill_brewer(palette = "Dark2")
ggsave(file.path(output_dir, "Degree_pie_chart.png"), plot = degree_plot, width = 10, height = 6, dpi = 300)
highest_degree <- degree_counts_long[which.max(degree_counts_long$Total), ]
lowest_degree <- degree_counts_long[which.min(degree_counts_long$Total), ]
print(paste("Degree level with the highest enrollment:", highest_degree$Degree))
print(paste("Degree level with the lowest enrollment:", lowest_degree$Degree))


#### Field of Study Analysis - Donut Chart
field_counts <- data %>%
  dplyr::select(dplyr::starts_with("FieldofStudy")) %>%
  summarize_all(sum)
field_counts_long <- pivot_longer(field_counts, cols = everything(), names_to = "Field.of.Study", values_to = "Total")
field_plot <- ggplot(field_counts_long, aes(x = "", y = Total, fill = `Field.of.Study`)) +
  geom_bar(stat = "identity", width = 1) +
  coord_polar(theta = "y", start = 0) +
  labs(title = "Donut Chart of International Students by Field of Study") +
  theme_void() +
  geom_text(aes(label = scales::comma(Total)), position = position_stack(vjust = 0.5)) +
  scale_fill_brewer(palette = "Paired")
ggsave(file.path(output_dir, "Field_study_donut_chart.png"), plot = field_plot, width = 10, height = 6, dpi = 300)
highest_field <- field_counts_long[which.max(field_counts_long$Total), ]
lowest_field <- field_counts_long[which.min(field_counts_long$Total), ]
print(paste("Field of study with the highest enrollment:", highest_field$`Field.of.Study`))
print(paste("Field of study with the lowest enrollment:", lowest_field$`Field.of.Study`))


#### Demographic Analysis - Gender Distribution by Year
demographic_data <- data %>%
  dplyr::select(Year, female, male) %>%
  pivot_longer(cols = c("female", "male"), names_to = "Gender", values_to = "Enrollment")

# Bar
demographic_plot <- ggplot(demographic_data, aes(x = Year, y = Enrollment, fill = Gender)) +
  geom_bar(stat = "identity", position = position_dodge()) +
  scale_fill_manual(values = c("#F8766D", "#00BFC4")) +  # Use manual colors similar to the uploaded chart
  labs(x = "Year", y = "Enrollment", title = "Gender Distribution of International Students Over Years") +
  theme_minimal() +
  theme(legend.position = "bottom") +
  geom_text(aes(label = scales::comma(Enrollment)), position = position_dodge(width = 0.9), vjust = -0.25, color = "white") +
  scale_y_continuous(labels = scales::comma)
ggsave(file.path(output_dir, "demographic_plot.png"), plot = demographic_plot, width = 10, height = 6, dpi = 300)

highest_female <- demographic_data %>% filter(Gender == "female") %>% slice(which.max(Enrollment))
highest_male <- demographic_data %>% filter(Gender == "male") %>% slice(which.max(Enrollment))
lowest_female <- demographic_data %>% filter(Gender == "female") %>% slice(which.min(Enrollment))
lowest_male <- demographic_data %>% filter(Gender == "male") %>% slice(which.min(Enrollment))
print(paste("Year with the highest female enrollment:", highest_female$Year))
print(paste("Year with the highest male enrollment:", highest_male$Year))
print(paste("Year with the lowest female enrollment:", lowest_female$Year))
print(paste("Year with the lowest male enrollment:", lowest_male$Year))


#### Funding Source Analysis - Horizontal Bar Chart
funding_counts <- data %>%
  summarize(
    International_Funding_Sources = sum(InternationalFundingSources),
    Personal_and_Family = sum(PersonalandFamily),
    Foreign_Government_or_University = sum(ForeignGovernmentorUniversity),
    Foreign_Private_Sponsor = sum(ForeignPrivateSponsor),
    International_Organization = sum(InternationalOrganization),
    US_Funding_Sources = sum(USFundingSources),
    Current_Employment = sum(CurrentEmployment),
    US_College_or_University = sum(USCollegeorUniversity),
    US_Government = sum(USGovernment),
    US_Private_Sponsor = sum(USPrivateSponsor),
    Other_Sources = sum(OtherSources)
  )
funding_counts_long <- pivot_longer(funding_counts, cols = everything(), names_to = "Funding_Source", values_to = "Count")

funding_plot <- ggplot(funding_counts_long, aes(x = reorder(Funding_Source, -Count), y = Count, fill = Funding_Source)) +
  geom_bar(stat = "identity") +
  coord_flip() +
  scale_fill_brewer(palette = "Set3") +
  labs(x = "Funding Source", y = "Number of Students", title = "Distribution of International Students by Funding Source")
ggsave(file.path(output_dir, "funding_plot.png"), plot = funding_plot, width = 10, height = 6, dpi = 300)

highest_funding_source <- funding_counts_long %>% slice_max(Count)
lowest_funding_source <- funding_counts_long %>% slice_min(Count)
print(paste("Funding source with the highest count:", highest_funding_source$Funding_Source))
print(paste("Funding source with the lowest count:", lowest_funding_source$Funding_Source))


#### Top Universities Analysis - Horizontal Bar Chart
top_universities <- data %>%
  dplyr::select(dplyr::contains("University")) %>%
  pivot_longer(cols = everything(), names_to = "University", values_to = "Enrollment")

university_plot <- ggplot(top_universities, aes(x = reorder(University, -Enrollment), y = Enrollment)) +
  geom_bar(stat = "identity") +
  coord_flip() +
  scale_fill_brewer(palette = "Set3") +
  labs(x = "Enrollment", y = "University", title = "Top Universities by Enrollment") +
  theme_minimal()
ggsave(file.path(output_dir, "top_universities_plot.png"), plot = university_plot, width = 10, height = 6, dpi = 300)

highest_university <- top_universities %>% slice(which.max(Enrollment))
lowest_university <- top_universities %>% slice(which.min(Enrollment))
print(paste("University with the highest enrollment:", highest_university$University))
print(paste("University with the lowest enrollment:", lowest_university$University))


#### Visa Status Analysis - Vertical Bar Chart
visa_counts <- data %>%
  summarize(F_Visa = sum(visa_f), J_Visa = sum(visa_j), Other_Visa = sum(visa_other))
visa_counts_long <- pivot_longer(visa_counts, cols = everything(), names_to = "Visa_Type", values_to = "Count")

visa_plot <- ggplot(visa_counts_long, aes(x = Visa_Type, y = Count, fill = Visa_Type)) +
  geom_bar(stat = "identity") +
  scale_fill_brewer(palette = "Set2") +
  labs(x = "Visa Type", y = "Number of Students", title = "Distribution of International Students by Visa Status")
ggsave(file.path(output_dir, "visa_plot.png"), plot = visa_plot, width = 10, height = 6, dpi = 300)

highest_visa_type <- visa_counts_long %>% slice(which.max(Count))
lowest_visa_type <- visa_counts_long %>% slice(which.min(Count))
print(paste("Visa type with the highest count:", highest_visa_type$Visa_Type))
print(paste("Visa type with the lowest count:", lowest_visa_type$Visa_Type))


#### Optional Practical Training (OPT) Analysis - Area Chart
opt_plot <- ggplot(data, aes(x = Year, y = OptionalPracticalTrainingOPT, fill = "OPT Participation")) +
  geom_area(alpha = 0.5, fill = brewer.pal(9, "Greens")[5]) +
  geom_line(color = brewer.pal(9, "Greens")[9]) +
  labs(x = "Year", y = "OPT Participation", title = "Trend of Optional Practical Training (OPT) Participation")
ggsave(file.path(output_dir, "opt_plot.png"), plot = opt_plot, width = 10, height = 6, dpi = 300)

highest_opt_year <- data %>% slice(which.max(OptionalPracticalTrainingOPT))
lowest_opt_year <- data %>% slice(which.min(OptionalPracticalTrainingOPT))
print(paste("Year with the highest OPT participation:", highest_opt_year$Year))
print(paste("Year with the lowest OPT participation:", lowest_opt_year$Year))

