library(ggplot2)
library(dplyr)

countryData <- read.csv("/Users/snehaagrawal/Documents/SEM 2/ML/Term Project/Dataset/Cleaned_CountryDistribution.csv")
print(names(countryData))

# Palette of pastel colors
pastel_colors <- c("#FFB6C1", "#FFC0CB", "#FFDAB9", "#E6E6FA", "#B0E0E6", "#98FB98", "#AFEEEE", "#F0E68C", "#DDA0DD", "#D8BFD8")

# Horizontal bar chart for 2022
country_plot_2022 <- ggplot(countryData, aes(x = X2022, y = reorder(Place_of_Origin, X2022), fill = Place_of_Origin)) +
  geom_bar(stat = "identity") +
  labs(x = "Enrollment in 2022", y = "Country", title = "International Student Enrollment by Country in 2022") +
  theme_minimal() +
  theme(axis.text.y = element_text(size = 8), legend.position = "none") +
  scale_fill_manual(values = rep(pastel_colors, length.out = nrow(countryData)))

ggsave("/Users/snehaagrawal/Documents/SEM 2/ML/Term Project/CountryAnalysis/Country_plot_2022.png", plot = country_plot_2022, width = 12, height = 10)

# Countries with maximum and minimum contributions in 2022
max_country_2022 <- countryData[which.max(countryData$X2022),]
min_country_2022 <- countryData[which.min(countryData$X2022[countryData$X2022 > 0]),]  # Assuming contributions greater than 0
print(paste("Country with the highest enrollment in 2022:", max_country_2022$Place_of_Origin))
print(paste("Country with the lowest enrollment in 2022:", min_country_2022$Place_of_Origin))

# Sorting data for 2022 and selecting top 10
countryData_top10_2022 <- countryData %>%
  arrange(desc(X2022)) %>%
  slice(1:10)

# Horizontal bar chart for the top 10 countries in 2022
top10_country_plot_2022 <- ggplot(countryData_top10_2022, aes(x = X2022, y = reorder(Place_of_Origin, X2022), fill = Place_of_Origin)) +
  geom_bar(stat = "identity") +
  labs(x = "Enrollment in 2022", y = "Country", title = "Top 10 Countries by International Student Enrollment in 2022") +
  theme_minimal() +
  theme(axis.text.y = element_text(size = 10), legend.position = "none") +
  scale_fill_manual(values = pastel_colors[1:10])  

ggsave("/Users/snehaagrawal/Documents/SEM 2/ML/Term Project/CountryAnalysis/Top10_country_plot_2022.png", plot = top10_country_plot_2022, width = 12, height = 8)

# Changes from 2012 to 2022
countryData <- countryData %>%
  mutate(Change_2012_to_2022 = X2022 - X2012)

max_increase <- countryData[which.max(countryData$Change_2012_to_2022),]
min_increase <- countryData[which.min(countryData$Change_2012_to_2022),]

cat("Country with the biggest increase from 2012 to 2022:", max_increase$Place_of_Origin, "\n")
cat("Increase:", max_increase$Change_2012_to_2022, "students\n")
cat("Country with the biggest decrease from 2012 to 2022:", min_increase$Place_of_Origin, "\n")
cat("Decrease:", min_increase$Change_2012_to_2022, "students\n")

# Top 10 countries with the largest increases
top10_increases <- countryData %>%
  arrange(desc(Change_2012_to_2022)) %>%
  slice(1:10)

cat("Top 10 countries with the largest increases from 2012 to 2022:\n")
print(top10_increases[, c("Place_of_Origin", "Change_2012_to_2022")])

# Bar plot for top 10 increases
top10_increases_plot <- ggplot(top10_increases, aes(x = reorder(Place_of_Origin, Change_2012_to_2022), y = Change_2012_to_2022, fill = Place_of_Origin)) +
  geom_col(show.legend = FALSE) +
  labs(x = "Country", y = "Increase in Enrollment", title = "Top 10 Countries by Increase in Student Enrollment from 2012 to 2022") +
  coord_flip() +
  theme_minimal() +
  scale_fill_manual(values = pastel_colors[1:10])  # Use pastel colors for top 10 increases

ggsave("/Users/snehaagrawal/Documents/SEM 2/ML/Term Project/CountryAnalysis/Top10_increases_plot_2012_to_2022.png", plot = top10_increases_plot, width = 10, height = 8)

# Reshape data from wide to long format
country_data_long <- countryData %>%
  pivot_longer(cols = starts_with("X"), names_to = "Year", values_to = "Enrollment", names_prefix = "X") %>%
  mutate(Year = as.numeric(Year))

# Line plot
country_plot_line <- ggplot(country_data_long, aes(x = Year, y = Enrollment, group = Place_of_Origin, color = Place_of_Origin)) +
  geom_line() +
  labs(x = "Year", y = "Enrollment", title = "International Student Enrollment Trends by Country") +
  theme_minimal() +
  theme(legend.position = "none") +
  scale_color_manual(values = rep(pastel_colors, length.out = length(unique(country_data_long$Place_of_Origin))))

ggsave("/Users/snehaagrawal/Documents/SEM 2/ML/Term Project/CountryAnalysis/Country_plot_line_trends.png", plot = country_plot_line, width = 12, height = 8)
