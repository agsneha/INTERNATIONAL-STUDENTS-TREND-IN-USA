library(dplyr)
library(ggplot2)
library(reshape2)
library(pheatmap)
library(ComplexHeatmap)
library(car)

data <- read.csv("/Users/snehaagrawal/Documents/SEM 2/ML/Term Project/Dataset/Cleaned_CombinedData.csv")
print(names(data))

# Only numeric columns for correlation matrix
numeric_data <- data[, sapply(data, is.numeric)]
correlation_matrix <- cor(numeric_data, use = "complete.obs")

print(correlation_matrix)

# Color palette for the heatmap
color_palette <- colorRampPalette(c("blue", "white", "red"))(50)

# Heatmap of the correlations 
png(filename = "/Users/snehaagrawal/Documents/SEM 2/ML/Term Project/heatmap_seaborn_style.png",
    width = 12 * 300, height = 12 * 300, res = 300)

pheatmap(correlation_matrix,
         color = color_palette,
         display_numbers = TRUE,
         clustering_distance_rows = "euclidean",
         clustering_distance_cols = "euclidean",
         fontsize = 6)

dev.off()


correlation_df <- as.data.frame(as.table(correlation_matrix))

correlation_df <- correlation_df[order(-abs(correlation_df$Freq)), ]

# Exclude the self-correlations of variables
correlation_df <- subset(correlation_df, Var1 != Var2)

cat("Most Significant Correlations:\n")
print(head(correlation_df, 5))
cat("\nLeast Significant Correlations:\n")
print(tail(correlation_df, 5))
