library(dplyr)
library(MASS)
library(glmnet)
library(caret)
library(randomForest)

data <- read.csv("/Users/snehaagrawal/Documents/SEM 2/ML/Term Project/Dataset/Cleaned_CombinedData.csv")

# Setting the seed 
set.seed(123)

# Calculating the indices for the 80-15-5 split
n <- nrow(data)
train_indices <- sample(seq_len(n), size = floor(0.80 * n))
remaining_indices <- setdiff(seq_len(n), train_indices)
test_indices <- sample(remaining_indices, size = floor(0.15 * length(remaining_indices)))
validation_indices <- setdiff(remaining_indices, test_indices)

# Data split
train_set <- data[train_indices, 1:44]
test_set <- data[test_indices, 1:44]
validation_set <- data[validation_indices, 1:44]


#### Multiple linear regression model 
m <- lm(TotalIntlStudents ~ ., data = train_set)
summary(m)  # Print the summary of the model

# Predict on the test and validation sets
predictions <- predict(m, newdata = test_set)
validation_predictions_mlr <- predict(m, newdata = validation_set)

# Extracting the actual values of the target variable from the test and validation sets
actuals <- test_set$TotalIntlStudents
validation_actuals <- validation_set$TotalIntlStudents

mse <- mean((predictions - actuals)^2)
validation_mse_mlr <- mean((validation_predictions_mlr - validation_actuals)^2)
rmse <- sqrt(mse)
validation_rmse_mlr <- sqrt(validation_mse_mlr)
sse <- sum((predictions - actuals)^2)
sst <- sum((actuals - mean(actuals))^2)
r_squared <- 1 - (sse/sst)
validation_sse_mlr <- sum((validation_predictions_mlr - validation_actuals)^2)
validation_sst_mlr <- sum((validation_actuals - mean(validation_actuals))^2)
validation_r_squared_mlr <- 1 - (validation_sse_mlr / validation_sst_mlr)

cat("Multiple Linear Regression Results:\n")
cat("Test MSE:", mse, "\nTest RMSE:", rmse, "\nTest R-squared:", r_squared, "\n")
cat("Validation MSE:", validation_mse_mlr, "\nValidation RMSE:", validation_rmse_mlr, "\nValidation R-squared:", validation_r_squared_mlr, "\n")
##### Overfitting issue experienced. 

# Data preparation for glmnet
x_train <- as.matrix(train_set[, -which(names(train_set) == "TotalIntlStudents")])
y_train <- train_set$TotalIntlStudents
x_test <- as.matrix(test_set[, -which(names(test_set) == "TotalIntlStudents")])
y_test <- test_set$TotalIntlStudents
x_validation <- as.matrix(validation_set[, -which(names(validation_set) == "TotalIntlStudents")])
y_validation <- validation_set$TotalIntlStudents


# Ridge Regression Model:
ridge_model <- glmnet(x_train, y_train, alpha = 0)

# Best lambda using cross-validation:
cv_ridge <- cv.glmnet(x_train, y_train, alpha = 0)
best_lambda_ridge <- cv_ridge$lambda.min
cat("Best Lambda for Ridge Regression:", best_lambda_ridge, "\n")

# Predicting and Evaluating the model using the best lambda
ridge_predictions <- predict(ridge_model, s = best_lambda_ridge, newx = x_test)
validation_predictions_ridge <- predict(ridge_model, s = best_lambda_ridge, newx = x_validation)
mse_ridge <- mean((ridge_predictions - y_test)^2)
validation_mse_ridge <- mean((validation_predictions_ridge - y_validation)^2)
rmse_ridge <- sqrt(mse_ridge)
validation_rmse_ridge <- sqrt(validation_mse_ridge)
sse_ridge <- sum((ridge_predictions - y_test)^2)
sst_ridge <- sum((y_test - mean(y_test))^2)
r_squared_ridge <- 1 - (sse_ridge / sst_ridge)
validation_sse_ridge <- sum((validation_predictions_ridge - y_validation)^2)
validation_sst_ridge <- sum((y_validation - mean(y_validation))^2)
validation_r_squared_ridge <- 1 - (validation_sse_ridge / validation_sst_ridge)

cat("Ridge Regression Results:\n")
cat("Test MSE:", mse_ridge, "\nTest RMSE:", rmse_ridge, "\nTest R-squared:", r_squared_ridge, "\n")
cat("Validation MSE:", validation_mse_ridge, "\nValidation RMSE:", validation_rmse_ridge, "\nValidation R-squared:", validation_r_squared_ridge, "\n")

# Nonzero coefficients from the Ridge model
ridge_coef <- coef(ridge_model, s = best_lambda_ridge)
selected_features_ridge <- rownames(ridge_coef)[ridge_coef[, 1] != 0]
cat("Selected Features by Ridge:", paste(selected_features_ridge, collapse = ", "), "\n")

# Lasso Regression Model:
lasso_model <- glmnet(x_train, y_train, alpha = 1)

# Best lambda using cross-validation
cv_lasso <- cv.glmnet(x_train, y_train, alpha = 1)
best_lambda_lasso <- cv_lasso$lambda.min
cat("Best Lambda for Lasso Regression:", best_lambda_lasso, "\n")

lasso_predictions <- predict(lasso_model, s = best_lambda_lasso, newx = x_test)
validation_predictions_lasso <- predict(lasso_model, s = best_lambda_lasso, newx = x_validation)
mse_lasso <- mean((lasso_predictions - y_test)^2)
validation_mse_lasso <- mean((validation_predictions_lasso - y_validation)^2)
rmse_lasso <- sqrt(mse_lasso)
validation_rmse_lasso <- sqrt(validation_mse_lasso)
sse_lasso <- sum((lasso_predictions - y_test)^2)
sst_lasso <- sum((y_test - mean(y_test))^2)
r_squared_lasso <- 1 - (sse_lasso / sst_lasso)
validation_sse_lasso <- sum((validation_predictions_lasso - y_validation)^2)
validation_sst_lasso <- sum((y_validation - mean(y_validation))^2)
validation_r_squared_lasso <- 1 - (validation_sse_lasso / validation_sst_lasso)

cat("Lasso Regression Results:\n")
cat("Test MSE:", mse_lasso, "\nTest RMSE:", rmse_lasso, "\nTest R-squared:", r_squared_lasso, "\n")
cat("Validation MSE:", validation_mse_lasso, "\nValidation RMSE:", validation_rmse_lasso, "\nValidation R-squared:", validation_r_squared_lasso, "\n")

lasso_coef <- coef(lasso_model, s = best_lambda_lasso)
selected_features_lasso <- rownames(lasso_coef)[lasso_coef[, 1] != 0]
cat("Selected Features by Lasso:", paste(selected_features_lasso, collapse = ", "), "\n")


# Recursive Feature Elimination (RFE) using random forests:
# Setting up control for RFE with cross-validation
control <- rfeControl(
  functions = rfFuncs, 
  method = "cv",        
  number = 10           
)

x_train <- train_set[, -which(names(train_set) == "TotalIntlStudents")]
y_train <- train_set$TotalIntlStudents

# Running RFE to select features
rfe_model <- rfe(
  x_train,
  y_train,
  sizes = c(1:ncol(x_train)),  
  rfeControl = control
)

print(rfe_model)
selected_features_rfe <- predictors(rfe_model)
cat("Selected Features by RFE:", paste(selected_features_rfe, collapse = ", "), "\n")

# Using selected features to train a new model
final_model <- lm(TotalIntlStudents ~ ., data = train_set[, c(selected_features_rfe, "TotalIntlStudents")])

summary(final_model)

# Prediction and Evaluation on test set
final_predictions <- predict(final_model, newdata = test_set[, c(selected_features_rfe, "TotalIntlStudents")])
validation_predictions_final <- predict(final_model, newdata = validation_set[, c(selected_features_rfe, "TotalIntlStudents")])

final_actuals <- test_set$TotalIntlStudents
validation_actuals_final <- validation_set$TotalIntlStudents

final_mse <- mean((final_predictions - final_actuals)^2)
validation_mse_final <- mean((validation_predictions_final - validation_actuals_final)^2)

final_rmse <- sqrt(final_mse)
validation_rmse_final <- sqrt(validation_mse_final)

final_sse <- sum((final_predictions - final_actuals)^2)
final_sst <- sum((final_actuals - mean(actuals))^2)
final_r_squared <- 1 - (final_sse / final_sst)

validation_sse_final <- sum((validation_predictions_final - validation_actuals_final)^2)
validation_sst_final <- sum((validation_actuals_final - mean(validation_actuals_final))^2)
validation_r_squared_final <- 1 - (validation_sse_final / validation_sst_final)

cat("RFE Model Results:\n")
cat("Test MSE:", final_mse, "\nTest RMSE:", final_rmse, "\nTest R-squared:", final_r_squared, "\n")
cat("Validation MSE:", validation_mse_final, "\nValidation RMSE:", validation_rmse_final, "\nValidation R-squared:", validation_r_squared_final, "\n")


# Data frame to store performance metrics for each model
model_metrics <- data.frame(
  Model = c("Multiple Linear Regression", "Ridge Regression", "Lasso Regression", "RFE Model"),
  Test_MSE = c(mse, mse_ridge, mse_lasso, final_mse),
  Validation_MSE = c(validation_mse_mlr, validation_mse_ridge, validation_mse_lasso, validation_mse_final),
  Test_RMSE = c(rmse, rmse_ridge, rmse_lasso, final_rmse),
  Validation_RMSE = c(validation_rmse_mlr, validation_rmse_ridge, validation_rmse_lasso, validation_rmse_final),
  Test_R_Squared = c(r_squared, r_squared_ridge, r_squared_lasso, final_r_squared),
  Validation_R_Squared = c(validation_r_squared_mlr, validation_r_squared_ridge, validation_r_squared_lasso, validation_r_squared_final)
)

print(model_metrics)

